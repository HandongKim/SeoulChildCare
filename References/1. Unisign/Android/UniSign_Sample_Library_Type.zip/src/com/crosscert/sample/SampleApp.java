package com.crosscert.sample;

import android.app.Application;

public class SampleApp extends Application {

	public final static String APP_LICENSEKEY = "gSXC8po2F81WKBU4YfXWpQ=="; //2017-06-30 라이센스
}
