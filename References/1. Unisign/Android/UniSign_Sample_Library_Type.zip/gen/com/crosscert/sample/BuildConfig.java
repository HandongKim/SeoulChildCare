/** Automatically generated file. DO NOT MODIFY */
package com.crosscert.sample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}